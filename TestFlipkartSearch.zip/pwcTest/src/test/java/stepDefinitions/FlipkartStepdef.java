package stepDefinitions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.FlipkartSearch;


public class FlipkartStepdef {
	
	FlipkartSearch fsearch;
	WebDriver driver;
	@Given("^User opens url \"([^\"]*)\"$")
	public void user_opens_url(String url){
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "//Drivers/chromedriver.exe");
		driver= new ChromeDriver();
		fsearch= new FlipkartSearch(driver);
		driver.get(url);
	}
	
	@And("^User Searches with \"([^\"]*)\"$")
   public void user_searches_with(String searchText){
		fsearch.clickCloseBtn();
		fsearch.setSearch(searchText);
		
		
	}
	
    @Then("^User clicks on the first product")
	public void user_clicks_on_the_first_product(){
			
		fsearch.clickFirstElement();
			
		}
	@Then("^User checks the addtocart option")
	public void user_checks_theaddtoCart_option(){
		
		String mainWindow= driver.getWindowHandle();
		Set<String> allWindoes = driver.getWindowHandles();
		Iterator <String> iterator= allWindoes.iterator();
		while (iterator.hasNext()){
			String childWindow = iterator.next();
			if(!mainWindow.equalsIgnoreCase(childWindow)){
				driver.switchTo().window(childWindow);
				Assert.assertTrue(fsearch.addToCart().isDisplayed());
				driver.close();
			}
			driver.switchTo().window(mainWindow);
		}
		
			
		}
	@And("^Close Browser$")
	public void close_Browser(){
		driver.close();
	}

	
}
