package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FlipkartSearch {
	
	WebDriver driver;
	
	public FlipkartSearch (WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		
	}
	@FindBy(xpath="/html/body/div[2]/div/div/button")
	WebElement closeBtn;
	
	@FindBy(xpath="//*[@id='container']//input[@placeholder='Search for products, brands and more']")
	WebElement searchBox;
	

	
	@FindBy(xpath="//*[@id='container']/div/div[3]/div[1]/div[2]/div[2]/div/div[1]/div/a[1]/div[1]/div/div/img")
	WebElement firstElement;
	
	@FindBy(xpath="//*[@id='container']//button[text()='ADD TO CART']")
	WebElement addtoCart;
	
	public void setSearch(String searchTxt){
		searchBox.sendKeys(searchTxt);
		searchBox.sendKeys(Keys.ENTER);
		
	}
	
	
	
	public void clickFirstElement(){
		WebDriverWait wait= new WebDriverWait (driver,30);
		wait.until(ExpectedConditions.elementToBeClickable(firstElement)).click();
	
	}
	
	public void clickCloseBtn(){
		closeBtn.click();
	}
	public WebElement addToCart(){
		return addtoCart;
	}



	
	
	
	
	
	

}
